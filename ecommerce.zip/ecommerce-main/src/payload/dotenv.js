module.exports = {
  config: () => null,
}
