module.exports = {
  url: () => {},
  raw: () => {},
}
